import Mutation from './mutation.resolver.js';
import Query from './query.resolver.js';

export { Mutation, Query };

