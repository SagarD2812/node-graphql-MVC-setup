// filepath: /D:/sagar D/Node js/graphql_test/src/resolvers/mutation.resolver.js
import UserController from '../controller/UserController.js';

const Mutation = {
  createUser: UserController.createUser,
};

export default Mutation;