import UserController from '../controller/UserController.js';

export default {
  getAllUsers: UserController.getAllUsers,
};